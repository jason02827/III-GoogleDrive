//
//  MasterViewController.h
//  20170427HellowMyGDrive
//
//  Created by user35 on 2017/4/27.
//  Copyright © 2017年 user35. All rights reserved.
//

#import <UIKit/UIKit.h>

@class DetailViewController;

@interface MasterViewController : UITableViewController

@property (strong, nonatomic) DetailViewController *detailViewController;


@end

