//
//  MasterViewController.m
//  20170427HellowMyGDrive
//
//  Created by user35 on 2017/4/27.
//  Copyright © 2017年 user35. All rights reserved.
//

#import "MasterViewController.h"
#import "DetailViewController.h"

#import <GoogleSignIn/GoogleSignIn.h>
#import <GTLDrive.h>

#define CLIENT_ID @"747213177523-eukuio3di1vnh16611tkektb95sp92jf.apps.googleusercontent.com"

@interface MasterViewController () <GIDSignInDelegate,GIDSignInUIDelegate>
{ GTLServiceDrive *drive; }

@property NSMutableArray *objects;
@end

@implementation MasterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
//    self.navigationItem.leftBarButtonItem = self.editButtonItem;
//
//    UIBarButtonItem *addButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(insertNewObject:)];
//    self.navigationItem.rightBarButtonItem = addButton;
    
    if (!self.objects) {
        self.objects = [[NSMutableArray alloc] init];
    }
    
    self.detailViewController = (DetailViewController *)[[self.splitViewController.viewControllers lastObject] topViewController];
    
    //Prepare Google SignIn
    GIDSignIn *signIn = [GIDSignIn sharedInstance];
    signIn.delegate = self;
    signIn.uiDelegate = self;
    
    signIn.scopes = @[kGTLAuthScopeDriveFile]; //我的app只能看到自己上傳的檔案//kGTLAuthScopeDrive可以看到全部
    signIn.clientID = CLIENT_ID;
    
    //Prepare GTLServiceDrive
    drive =[GTLServiceDrive new];
    drive.authorizer = signIn.currentUser.authentication.fetcherAuthorizer;  //authorizer是認證
    
    //Check if we should login
    if ([drive.authorizer canAuthorize]) {
        //True的話Already login
        [self startGDriveFunction];
    }else{
        //False的話Need to login
        [signIn signIn];
    }
}
#pragma mark - GIDSignInDelegate Methods

-(void)signIn:(GIDSignIn *)signIn didSignInForUser:(GIDGoogleUser *)user withError:(NSError *)error{  //是login的結果
    
    if (error) {
        NSLog(@"Auth Fail: %@",error);
        return;
    }
    drive.authorizer = user.authentication.fetcherAuthorizer;
    
    if ([drive.authorizer canAuthorize]) { //檢查
        [self startGDriveFunction];
    }
}

-(void) startGDriveFunction{
    
    self.navigationItem.leftBarButtonItem = self.editButtonItem;
    
    UIBarButtonItem *addButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(insertNewObject:)];
    self.navigationItem.rightBarButtonItem = addButton;

    [self downloadFileList];
    
}

-(void)downloadFileList{
    
    if (_objects==nil) {
        _objects = [NSMutableArray new];
    }else{
        [_objects removeAllObjects];
    }
    //Query for file list
    drive.shouldFetchNextPages = true;
    
    GTLQueryDrive *query = [GTLQueryDrive queryForFilesList];
    query.q = [NSString stringWithFormat:@"'%@' IN parents",@"root"];
    
    [drive executeQuery:query completionHandler:^(GTLServiceTicket *ticket, GTLDriveFileList *result, NSError *error) {
        if (error) {
            NSLog(@"Query File List Fail: %@",error);
        }else{
            [_objects addObjectsFromArray:result.files];
            //Ask tableview to reload
            [self.tableView reloadData];
        }
    }];
    
}

- (void)viewWillAppear:(BOOL)animated {
    self.clearsSelectionOnViewWillAppear = self.splitViewController.isCollapsed;
    [super viewWillAppear:animated];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void)insertNewObject:(id)sender {
    //Prepare upload data
    NSURL *fileURL = [[NSBundle mainBundle]URLForResource:@"cat.png" withExtension:nil];
    NSData *fileData = [NSData dataWithContentsOfURL:fileURL];
    
    //Prapare GTLDriveFile
    GTLDriveFile *file = [GTLDriveFile new];
    file.name = [NSString stringWithFormat:@"KentClass_%@",[NSDate date]];
//    file.originalFilename = @"abc.jpg";
    file.descriptionProperty = @"KentClassFile";
    file.mimeType = @"image/png";
//    file.mimeType = @"image/jpg";
    
    //Prapare parameters of upload
    GTLUploadParameters *parameters = [GTLUploadParameters uploadParametersWithData:fileData MIMEType:file.mimeType];
    GTLQueryDrive *query = [GTLQueryDrive queryForFilesCreateWithObject:file uploadParameters:parameters];
    
    //Perform upload action
    GTLServiceTicket *ticket = [drive executeQuery:query completionHandler:^(GTLServiceTicket *ticket, id object, NSError *error) {  //非同步
        
        if (error) {
            NSLog(@"Upload Fail: %@",error);
        }else{
            NSLog(@"Upload Success");
            [self downloadFileList];
        }
    }];
    
//    if (!self.objects) {
//        self.objects = [[NSMutableArray alloc] init];
//    }
//    [self.objects insertObject:[NSDate date] atIndex:0];
//    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:0];
//    [self.tableView insertRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
}


#pragma mark - Segues

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([[segue identifier] isEqualToString:@"showDetail"]) {
        NSIndexPath *indexPath = [self.tableView indexPathForSelectedRow];
//        NSDate *object = self.objects[indexPath.row];
        GTLDriveFile *file = self.objects[indexPath.row];
        DetailViewController *controller = (DetailViewController *)[[segue destinationViewController] topViewController];

//        [controller setDetailItem:object];
        [controller setDetailItem:file];
        controller.drive = drive;
        controller.navigationItem.leftBarButtonItem = self.splitViewController.displayModeButtonItem;
        controller.navigationItem.leftItemsSupplementBackButton = YES;
    }
}


#pragma mark - Table View

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.objects.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];

//    NSDate *object = self.objects[indexPath.row];
    GTLDriveFile *file = self.objects[indexPath.row];
    cell.textLabel.text = file.name;
    return cell;
}


- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}


- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        
        GTLDriveFile *file = _objects[indexPath.row];
        GTLQueryDrive *query = [GTLQueryDrive queryForFilesDeleteWithFileId:file.identifier];
        
        [drive executeQuery:query completionHandler:^(GTLServiceTicket *ticket, GTLDriveFile *file, NSError *error) {
            if (error) {
                NSLog(@"%@",error);
            }else{
                NSLog(@"");
                [self downloadFileList];
            }
        }];
        
//        [self.objects removeObjectAtIndex:indexPath.row];
//        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
        
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        
        
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
    }
}


@end
