//
//  DetailViewController.h
//  20170427HellowMyGDrive
//
//  Created by user35 on 2017/4/27.
//  Copyright © 2017年 user35. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <GTLDrive.h>
@interface DetailViewController : UIViewController

//@property (strong, nonatomic) NSDate *detailItem;
@property (strong, nonatomic) GTLDriveFile *detailItem;
@property (strong,nonatomic) GTLServiceDrive *drive;
@property (weak, nonatomic) IBOutlet UILabel *detailDescriptionLabel;

@end

