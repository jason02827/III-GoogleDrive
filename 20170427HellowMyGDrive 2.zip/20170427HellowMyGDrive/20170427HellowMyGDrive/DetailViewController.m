//
//  DetailViewController.m
//  20170427HellowMyGDrive
//
//  Created by user35 on 2017/4/27.
//  Copyright © 2017年 user35. All rights reserved.
//

#import "DetailViewController.h"

@interface DetailViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *photoImageView;

@end

@implementation DetailViewController

- (void)configureView {
    // Update the user interface for the detail item.
    if (self.detailItem) {
        self.detailDescriptionLabel.text = [self.detailItem description];
        
        //Download file
        GTLDriveFile *file = self.detailItem;
        self.title = file.name;
        NSString *urlString = [NSString stringWithFormat:@"https://www.googleapis.com/drive/v2/files/%@?alt=media",file.identifier];
                               
        GTMSessionFetcher *fetcher = [_drive.fetcherService fetcherWithURLString:urlString];
        [fetcher beginFetchWithCompletionHandler:^(NSData * _Nullable data, NSError * _Nullable error) {
            if (error) {
                NSLog(@"");
            }else{
                _photoImageView.image = [UIImage imageWithData:data];
            }
        }];
                               
    }
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self configureView];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - Managing the detail item

- (void)setDetailItem:(/*NSDate*/GTLDriveFile *)newDetailItem {
    if (_detailItem != newDetailItem) {
        _detailItem = newDetailItem;
        
        // Update the view.
        [self configureView];
    }
}


@end
